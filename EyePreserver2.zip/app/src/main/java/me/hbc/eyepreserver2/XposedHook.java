package me.hbc.eyepreserver2;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;
import de.robv.android.xposed.callbacks.XCallback;
import de.robv.android.xposed.XposedBridge;

import android.hardware.Sensor;
import android.hardware.SystemSensorManager;
import java.util.HashMap;

public class XposedHook implements IXposedHookLoadPackage
{
	private static boolean DEBUG = true;
	
	protected static class MethodHook extends XC_MethodHook
	{

		@Override
		protected void beforeHookedMethod(MethodHookParam param)
		throws Throwable
		{
			int handle = (int) param.args[0];
			
			SystemSensorManager mManager = (SystemSensorManager) XposedHelpers.getObjectField(param.thisObject, "mManager");
			HashMap<Integer, Sensor> mHandleToSensor = (HashMap) XposedHelpers.getObjectField(mManager, "mHandleToSensor");
			Sensor mSensor = mHandleToSensor.get(handle);
			
			if (DEBUG) XposedBridge.log("param : " + String.valueOf(handle));
			
			if (DEBUG) XposedBridge.log("Sensor.TYPE_LIGHT : " + String.valueOf(android.hardware.Sensor.TYPE_LIGHT));
			
			if (DEBUG) XposedBridge.log("mSensor.getType() : " + String.valueOf(mSensor.getType()));
			
//			if (handle != 8)
			if (mSensor.getType() != Sensor.TYPE_LIGHT)
			{
				// not an Ambient Light Sensor
				return;
			}

			float[] values = (float[]) param.args[1];
			
			if (DEBUG) XposedBridge.log("lux before : " + String.valueOf(values[0]));

			float lux = values[0];
			if (lux < 180f)
			{
				lux += 8f + (181f - lux) / 181;
			}

			values[0] = lux;
			
			if (DEBUG) XposedBridge.log("lux after : " + String.valueOf(lux));

			// invoke the original method after exit from this method
		}

		// Singleton-like: all instances are the same to avoid
		// unnecessary repeated filtering (don't know where it comes from).

		@Override
		public int compareTo(XCallback other)
		{
			if (this.equals(other))
			{
				return 0;
			}
			return super.compareTo(other);
		}

		@Override
		public boolean equals(Object o)
		{
			if (o instanceof MethodHook)
			{
				return true;
			}
			return super.equals(o);
		}

		@Override
		public int hashCode()
		{
			return ~MethodHook.class.hashCode() ^ 0xdeadbeef;
		}

	}

	@Override
	public void handleLoadPackage(final LoadPackageParam lpparam) throws Throwable
	{
		XposedHelpers.findAndHookMethod(
			"android.hardware.SystemSensorManager$SensorEventQueue",
			lpparam.classLoader,
			"dispatchSensorEvent",
			int.class, float[].class, int.class, long.class,
			new MethodHook());
	}

}
